import 'package:get/get.dart';

import '../modules/book_list/views/BookListView.dart';
import '../modules/book_detail/views/book_detail_view.dart';
import '../modules/add_book/views/add_book_view.dart';
import '../modules/update_book/views/update_book_view.dart';
import '../modules/delete_book/views/delete_book_view.dart';
import '../modules/borrowed_book/views/borrowed_book_view.dart';
import '../modules/return_book/views/return_book_view.dart';
import '../modules/login/views/login_view.dart';


part 'app_routes.dart';

class AppPages {
  static final routes = [
    GetPage(name: '/book_list', page: () => BookListView()),
    GetPage(name: '/book_detail', page: () => BookDetailView()),
    GetPage(name: '/add_book', page: () => AddBookView()),
    GetPage(name: '/update_book', page: () => UpdateBookView()),  // Tambahkan ini
    GetPage(name: '/delete_book', page: () => DeleteBookView()),
    GetPage(name: '/borrowed_book', page: () => BorrowedBookView()),
    GetPage(name: '/return_book', page: () => ReturnBookView()),
    GetPage(name: '/', page: () => LoginView()),  // Tambahkan ini
  ];
}
